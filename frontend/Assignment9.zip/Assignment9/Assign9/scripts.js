var jsonData = [
    {
        "Id": 1,
        "Movie": "Harry Potter",
        "Actor": "Daniel Radcliffe",
        "Character": "Harry Potter"
    },
    {
        "Id": 2,
        "Movie": "Avatar",
        "Actor": "Sam Worthington",
        "Character": "Jake"
    },
    {
        "Id": 3,
        "Name": "Aladdin",
        "Actor": "Scott Weinger",
        "Chartacter": "Aladdin"
    },
    {
        "Id": 4,
        "Name": "La La Land",
        "Actor": "Ryan Gosling",
        "Character": "Sebastian"
    }
]