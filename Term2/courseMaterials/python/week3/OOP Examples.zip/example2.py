"""
Create a Car class with two instance attributes:

.color, which stores the name of the car’s color as a string
.mileage, which stores the number of miles on the car as an integer
Then instantiate two Car objects—a blue car with 20,000 miles 
and a red car with 30,000 miles—and print 
out their colors and mileage. Your output should look like this:
"""

class Car:

    def __init__(self, color , mileage):
        self.color = color
        self.mileage = mileage
    #setter
    def setColor(self, c):
        self.color = c 
    # getter method
    def getColor(self):
        return self.color
    
    def setMileage(self, m):
        self.mileage = m
    def getMileage(self):
        return self.mileage 

c1 = Car("Blue" , 20000)

c2 = Car("Red", 30000)


print("car1 info",c1.color, c1.mileage)
print("car2 info",c2.color, c2.mileage)
# car3 get input from the user
color = input("Enter car color: ")
mileage = int(input("Enter car mileage: "))

c3 = Car(color , mileage)

print(f"Car3 info: color  {c3.getColor()} mileage: {c3.getMileage()}")