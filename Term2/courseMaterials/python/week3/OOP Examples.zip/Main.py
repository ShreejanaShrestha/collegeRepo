
class Student:
    
    def __init__(self,n ,a):
        self.name = n
        self.age = a

    def getName(self):
        return self.name
    def setName(self,n):
        self.name = n
    # add set age method
    def setAge(self , a):
        self.age = a
    # add get age method
    def getAge(self):
        return self.age

s = Student("Susan" , 30)

print(s.getName(),  s.age)

s2 = Student("Tim" ,25)
s2.setName("Reem")
s2.setAge(27)
print(s2.getName() , s2.getAge())
