class Student:
    pass