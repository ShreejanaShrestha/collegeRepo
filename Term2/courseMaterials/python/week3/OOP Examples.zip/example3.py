
"""
Create a Circle class with two instance attributes:
name, which stores the name of the circle as a string
radius, which stores the radius of the circle as float 

Define the following methods
__init__
getRadius  // return radius value 
setRadius  //allow the user to set the radius 
getArea :  should return the area of the circle  (radius *radius * pi)

"""

class Circle:

    def __init__(self, n , r):
        self.name = n
        self.radius = r

    # setters 

    def setRadius(self, r):
        self.radius = r

    #getters 

    def getRadius(self):
        return self.radius

    def getArea(self):
        return self.radius * self.radius * 3.14


circle = Circle("circle1" ,10)

print(f"{circle.name} radius = {circle.getRadius()} area = {circle.getArea()}")