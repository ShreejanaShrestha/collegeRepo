s1 = set([1,2,3, "tim"])

print(s1)
s1.add(20)
s1.add(20)
len(s1)
for i in s1:
    print(i)