list = [ 1,2,3,4,5,6,7,8, 2 ,3]
list2 = [200 , 300 , 400 ,500]
print(list)
print(list[0])
print(list[2:6])
print(list[-4:-1])

#list.append(3)
#list.append(2)

#list.extend(list2)
list3 = list + list2
print(list)
print(list3)

name = "Tim"

list4 = list(name)