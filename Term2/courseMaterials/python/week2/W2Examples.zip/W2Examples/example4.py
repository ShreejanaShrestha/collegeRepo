d = {}

d["Tim"] = "tim@yahoo.ca"
d["Jane"] = "jane@yahoo.ca"
d[22] = "Mark"


print(d)


d2 = {
    22 : "Jane",
    33  : "Mike",
    25 : "Susan"

}

keys = d2.keys()
print(d2[22])
print(keys)

for k in keys :
    print(d2[k])


items = d2.items()

for i in items:
    print(i)