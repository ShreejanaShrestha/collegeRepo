list = [1,2 , 3, 4,5,7,9,70,80]
sum = 0
for y in list:
    sum += y

print(sum)
print(list[::-1])


