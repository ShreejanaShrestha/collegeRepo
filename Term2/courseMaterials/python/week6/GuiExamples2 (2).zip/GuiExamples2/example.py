import tkinter as tk
from tkinter import ttk
def clickMe():
    print("hello",name.get())
    print("you selected the value ",number.get())
    print("checkBtnthe value ",option.get())

win = tk.Tk()
#add your code here
name = tk.StringVar()
name_entered = ttk.Entry(win, width =12, textvariable=name)
name_entered.grid(column=0, row=1)

action = ttk.Button(win,text="Submit" , command=clickMe)
action.grid(column=2 , row=1)
number =tk.StringVar()

cb = ttk.Combobox(win,width=12 , textvariable=number)
cb["values"] = (1,3,4,6,100)
cb.grid(column=1, row=1)
option= tk.IntVar()
checkBtn = tk.Checkbutton(win, text="Add tax", variable=option)
checkBtn.grid(column=2,row=4)
win.mainloop()