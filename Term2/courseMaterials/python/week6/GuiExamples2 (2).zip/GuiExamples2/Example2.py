import tkinter as tk
from tkinter import ttk

def userSelection():
   print("selection")
   list.append("C")
   langs = tk.Variable(value=list)
   listBox.update()

   indices = listBox.curselection()
   i = indices[0]
   for n in indices:
        print(list[n])

win = tk.Tk()

list = ["java" , "C++" , "Python" , "C#"  , "Swift" , "JavaScript"]

langs = tk.Variable(value=list)

listBox = tk.Listbox(win , listvariable=langs , selectmode = tk.EXTENDED)
listBox.grid(column=0, row=1)
btn = tk.Button(win, text = "Display Selection" , command=userSelection)
btn.grid(column=1, row=1)


win.mainloop()
