-- Information about source code in USER_SOURCE
SELECT * FROM USER_SOURCE WHERE NAME = 'ADD_DEPT1';