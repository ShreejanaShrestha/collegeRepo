-- Invoke the procedure 
BEGIN 
    raise_salary1(120, 6.5); 
END;