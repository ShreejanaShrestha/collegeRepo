-- Invoke the procedure 
BEGIN 
    add_dept_with_parms1(25,'IT'); -- Parameters are passed by positional notation by default 
END;