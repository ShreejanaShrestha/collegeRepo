DECLARE 
    e_invalid_department        EXCEPTION;
    v_name                      VARCHAR2(20) := 'accounting';
    v_deptno                    VARCHAR2(2) := '  ';
BEGIN
    UPDATE departments
        SET department_name = v_name
        WHERE department_code = v_deptno;
    IF SQL%NOTFOUND then
        RAISE e_invalid_department;
    END IF;
    COMMIT;
EXCEPTION
    WHEN e_invalid_department THEN
         DBMS_OUTPUT.PUT_LINE('No such department code');
         ROLLBACK;
END;         
    
    