DECLARE
    v_manager_id        employees.manager_id%TYPE := 125;
BEGIN
    DELETE FROM employees
        WHERE manager_id = v_manager_id;
    IF SQL%NOTFOUND THEN
        RAISE_APPLICATION_ERROR(-20202, 'This is not a valid manager');
    END IF;
END;    