DECLARE
    e_insert_excep      EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_insert_excep, -1400);
BEGIN
    INSERT INTO departments (department_code, department_name)
        VALUES(28, NULL);
EXCEPTION
    WHEN e_insert_excep THEN
        DBMS_OUTPUT.PUT_LINE('Insert failed');
END;        