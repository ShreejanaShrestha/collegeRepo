DECLARE
    v_employee_id employees.employee_id%TYPE;
    v_manager_id            employees.manager_id%TYPE := 125;    -- Try 125 & 100
BEGIN
    SELECT employee_id INTO v_employee_id
        FROM employees
        WHERE manager_id = v_manager_id;
    DBMS_OUTPUT.PUT_LINE('The employee who works for manager_id '
        || v_manager_id || 'is: ' || v_employee_id);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20201, 'This manager has no employees');
    WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20202, 'Too many employees were found');
END;