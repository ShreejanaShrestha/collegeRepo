DROP TABLE error_log;
CREATE TABLE
    error_log(e_user VARCHAR2(30),
    e_date DATE,
    error_code VARCHAR2(20),
    error_message VARCHAR2(100));