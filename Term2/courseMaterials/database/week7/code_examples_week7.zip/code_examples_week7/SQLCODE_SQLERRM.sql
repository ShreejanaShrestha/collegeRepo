-- Execute the block
-- This code raises a TOO_MANY ROWS exception: ORA-01422

DECLARE
    v_error_code        NUMBER;
    v_error_message     VARCHAR2(255);
    v_last_name         employees.employee_id%TYPE;
BEGIN
    SELECT last_name INTO v_last_name
        FROM employees
        WHERE job_code = 'ST_Clerk';
EXCEPTION
    WHEN OTHERS THEN
        v_error_code := SQLCODE;
        v_error_message := SQLERRM;
        INSERT INTO error_log(e_user, e_date, error_code, error_message)
            VALUES(USER, SYSDATE, v_error_code, v_error_message);
END;            