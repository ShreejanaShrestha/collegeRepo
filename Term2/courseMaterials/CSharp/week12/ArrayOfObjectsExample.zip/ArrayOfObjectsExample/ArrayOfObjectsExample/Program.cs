﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayOfObjectsExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaring array of objects
            Student[] lambton = new Student[100];

            lambton[0] = new Student(101, "Amandeep Singh", "aman@mylambton.ca", 80, 70, 87, 65, 70);
            lambton[1] = new Student(102, "Ramandeep Singh", "raman@mylambton.ca", 51, 60, 87, 65, 70);

            lambton[0].Result();
            lambton[0].PrintResult();

            lambton[1].Result();
            lambton[1].PrintResult();

            Console.ReadKey();


        }
    }
}
