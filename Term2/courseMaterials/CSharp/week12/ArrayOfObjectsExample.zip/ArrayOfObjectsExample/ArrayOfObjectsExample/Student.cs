﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayOfObjectsExample
{
    class Student
    {
        private int studentID;
        String studName, email, grade;
        Double test1, test2, test3, assignment1, assignment2;
        Double coursetotal;

        public Student()
        {

        }

        public Student(int studentID, String studName, String email, double t1, double t2, double t3, double a1, double a2)
        {
            this.studentID = studentID;
            this.studName = studName;
            this.email = email;
            test1 = t1; test2 = t2 = 2; test3 = t3; assignment1 = a1; assignment2 = a2;


        }

        public double Result()
        {
            double total;

            total = test1 * 0.3 + test1 * 0.3 + test1 * 0.3 + assignment1 * 0.05 + assignment2 * 0.05;

            coursetotal = total;
            return total;

        }

        public void PrintResult()
        {
            Console.WriteLine(" ---------Course Result------------------- ");
            Console.WriteLine(" _________________________________________________________________ ");
            Console.WriteLine("Name = {0}, Student ID= {1}, Email = {2}", studName, studentID, email);
            Console.WriteLine("Test 1= {0}, Test 2= {1}, Test 3 = {2}", test1, test2, test3);
            Console.WriteLine("Assignment 1= {0}, Assignment 2 = {1}", assignment1, assignment2);
            Console.WriteLine(" _________________________________________________________________ ");
            Console.WriteLine("Course Total :                {0}    ", coursetotal);
            Console.WriteLine(" _________________________________________________________________ ");

        }
    }
}
