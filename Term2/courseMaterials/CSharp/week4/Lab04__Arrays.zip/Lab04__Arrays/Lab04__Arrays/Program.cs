﻿using System.Collections.Generic;
namespace Lab04__Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] marks = { 45, 49, 35, 40, 25, 30, 50, 41 };
            Console.WriteLine("Array lengh: {0}", marks.Length);
            int sum = 0;
            string marksString = "";
            for (int i = 0; i < marks.Length; i++)
            {
                marksString += marks[i] + " ";
                sum += marks[i];
            }
            Console.WriteLine(marksString);
            Console.WriteLine("Sum: {0}", marks.Sum());
            Console.WriteLine("Sum: {0}", sum);
            Console.WriteLine("Average: {0}", (double)(sum / marks.Length));
            Console.WriteLine("Average: {0}", (double)(marks.Sum() / marks.Length));

            // create a string array with names
            string[,] names = {
                                { "Clark Kent", "Superman", "DC" },
                                { "Barry Allen", "The Flash", "DC"},
                                { "Oliver Queen", "Green Arrow","DC" }
                              };
            Console.WriteLine("Real Name \tHero Name \tComics");
            Console.WriteLine("===========================================");
            for (int i = 0; i < names.GetLength(0); i++)
            {
                for (int j = 0; j < names.GetLength(1); j++)
                {
                    Console.Write(names[i, j] + "\t");
                }
                Console.WriteLine();
            }
            //foreach (string name in names)
            //{
            //    Console.WriteLine(name);
            //}
            // jagged array 
            Console.WriteLine('\n');
            int[][] jArray2 = new int[3][] {
                                    new int[3] { 1, 3, 2 },// 3 elements 
                                    new int[4] { 6, 4, 9, 7 }, // 4 elements 
                                    new int[2] { 7, 8  } // 2 elements
                                    };
            for (int i = 0; i < jArray2.GetLength(0); i++)
            {
                Console.Write("[");
                for (int j = 0; j < jArray2[i].Length; j++)
                {
                    Console.Write(jArray2[i][j] + "\t");
                }
                Console.Write("]\n");
                //Console.WriteLine("\n");
            }

            // create a List of names
            List<string> strings = new List<string>();
            strings.Add("Clark Kent");
            strings.Add("Brunce Banner");
            strings.Add("Steve Rogers");
            strings.Add("Barry Allen");
            foreach (var item in strings)
            {
                Console.WriteLine("Name: " + item);
            }

        }
    }
}
