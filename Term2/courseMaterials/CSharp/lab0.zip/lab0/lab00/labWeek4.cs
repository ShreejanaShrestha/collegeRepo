﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab00
{
    public class labWeek4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello");
        }
    }
}
