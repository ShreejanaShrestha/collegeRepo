﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // type [] name = initialize 
            int[] fibo = new int[10];
            // 0 1 2 3 4 5 6 7 8 9 <-- array index starts with zero 
            fibo[0] = 5;
            fibo[1] = 8;

            int[] mynumbers = { 0, 2, 4, 6, 7, 5, 8, 3, 1, 9 };
            string[] superheros = { "Superman", "Batman", "Green Arrow", "Flash", "Green Lantern", "Shazam", "Black Adam", "Deathstroke", "Green Canary"};
            int arrayLength = mynumbers.Length;

            Console.WriteLine("array length: {0}", arrayLength);
            for (int i = 0; i < arrayLength; i++)
            {
                Console.WriteLine("index {0}: value {1}", i, mynumbers[i]);
            }
            Console.WriteLine("************************");
            for (int i = 0; i < superheros.Length; i++)
            {
                Console.WriteLine("index {0}: value {1}", i, superheros[i]);
            }
            /*
             * 2D Array
                1x1 1x2 1x3
                2x1 2x2 2x3
                3x1 3x2 3x3
            */
            double[,] array2d = new double[4, 3]
            {
                { 1.1, 1.2, 1.3 },
                { 2.1, 2.2, 2.3 },
                { 3.2, 3.2, 3.3 },
                { 4.2, 4.2, 4.3 }
            };

            //Console.WriteLine(array2d.GetLength(1)); // GetLength 0- rows, 1- columns
            Console.WriteLine("************************");
            for (int i = 0; i < array2d.GetLength(0); i++)
            {
                for (int j = 0; j < array2d.GetLength(1); j++)
                {
                    Console.Write(array2d[i, j] + "\t");
                }
                Console.WriteLine();
            }
            //array2d[0, 0] = 1.1;
            //array2d[0, 1] = 1.2;
            //array2d[0, 3] = 1.3;

            // Jagged array is a array of arrays such that member arrays can be of different sizes.
            // In other words, the length of each array index can differ.
            // The elements of Jagged Array are reference types and initialized to null by default. 
            int[][] jArr1 = new int[2][];
            jArr1[0] = new int[3] { 1, 2, 3};
            jArr1[1] = new int[4] { 1, 2, 3, 4 };
            string[][] jSuperHeros = new string[2][];
            jSuperHeros[0] = new string[6] { "Ironman", "Hulk", "Thor", "Captain America", "Black Widow", "Hawkeye"};
            jSuperHeros[1] = new string[5] { "Superman", "Batman", "The Flash", "Aquaman", "Cyborg" };

            int[][,] jArr2 = new int[2][,];
            jArr2[0] = new int[2, 2] { 
                { 1, 2 }, 
                { 3, 4 } 
            };
            jArr2[1] = new int[3, 2] { 
                { 1, 2 }, 
                { 3, 4 }, 
                { 5, 6 } 
            };

            //Problem 1: write a program to sort an array in asending order
            int[] sortme = { 9, 2, 4, 6, 7, 5, 8, 3, 1, 0 };
            /* check values by their asending index
             * compare the value in each index with the array
             * get the smallest value and store in the array in the asending order
             * move small numbers to left 
             * move large numbers to right
             */
            for (int i = 0; i < sortme.Length; i++)
            {
                for (int j = 0; j < sortme.Length; j++)
                {
                    if (sortme[i] < sortme[j])
                    {
                        // store the value 
                        int temp = sortme[i];
                        // left swap 
                        sortme[i] = sortme[j];
                        // right swap
                        sortme[j] = temp;
                    }
                }
            }
            Console.WriteLine("***************************");
            for (int i = 0; i < sortme.Length; i++)
            {
                Console.Write(sortme[i] + "\t");
            }

            // problem 2: print first 20 Fibonacci numbers 
            // the Fibonacci sequence, in which each number is the sum of the two preceding ones. 
            //  0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181.
            // hint: you will have to know your last two indexes, then you can add them
            int n1 = 0, n2 = 1;
            
            // take this exercise as a homework 
        }
    }
}

