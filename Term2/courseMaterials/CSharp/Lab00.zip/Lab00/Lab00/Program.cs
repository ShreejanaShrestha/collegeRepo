﻿using System;

namespace Lab00
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Whats your name");
            //string x  = Console.ReadLine();
            //Console.WriteLine("Hello " + x + ", Welcome to the real world");

            string x = "1";
            int y = 10;
            double z = 100;

            char c = 'x';
            bool flag = true;
            const double hst = 13;
            
            //Console.WriteLine(x + y);
            //Console.WriteLine(x + z);
            //Console.WriteLine(y + z);
            //Console.WriteLine(x + y + z);

            Console.WriteLine("Enter the total amount");
            double total = Convert.ToDouble(Console.ReadLine());
            double tax = total * hst / 100;
            Console.WriteLine("---------------------");
            Console.WriteLine("Purchase Amount: " + total);
            Console.WriteLine("Tax " + hst + "%: " + tax);
            Console.WriteLine("---------------------");
            Console.WriteLine("Total: " + (total + tax));
            Console.WriteLine("---------------------");

        }
    }
}
